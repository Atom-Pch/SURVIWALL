# SURVIWALL
*Computer Vision project*

*2/2024*

*06016474 STIT 2 (Computer Vision)*

## Prerequisites
1. Create virtual environment
```
py -m venv <YOUR venv name>
```
> [!IMPORTANT]
> **<ins>Activate your virtual environment</ins>**

2. Install libraries in reqs.txt
```
pip install -r reqs.txt
```
